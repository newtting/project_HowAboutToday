package com.phoenix.howabouttoday;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HowAboutTodayApplicationTests {

	@Test
	void contextLoads() {
	}

}
